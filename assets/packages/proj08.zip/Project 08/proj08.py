''' Insert heading comments here.'''

def open_file():
    '''Insert docstring here.'''
    pass  #delete and place code here

def read_file(fp):
    '''Insert docstring here.'''
    pass  #delete and place code here


def food_and_minerals(D):
    '''Insert docstring here.'''
    pass  #delete and place code here

def build_dictionary(D,line_list):
    '''Insert docstring here.'''
    pass  #delete and place code here

def search(minerals_str,minerals_list,D):
    '''Insert docstring here.'''
    pass  #delete and place code here

def anti_anemia(D):
    '''Insert docstring here.'''
    pass  #delete and place code here

#Main function
def main():
    '''Insert docstring here.'''
    pass  #delete and place code here

#DO NOT DELETE THE NEXT TWO LINES
if __name__ == "__main__":
    main()
