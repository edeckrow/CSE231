import cards

# Create the deck of cards
the_deck = cards.Deck()

