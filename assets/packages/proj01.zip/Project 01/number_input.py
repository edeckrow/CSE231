# first program in python
# input two numbers, add them together, print them out
# wfp, 9/1/07; rje, 5/5/14

num_str1 = input('Please enter an integer: ')
num_str2 = input('Please enter a floating point number: ')

int1 = int(num_str1)
float1 = float(num_str2)

print('The numbers are: ',int1,' and ',float1)
print('Their sum is: ',int1+float1, 'Their product is:',int1*float1)
